# Kopi Senja: OOP Assignment 2

## How to run
    javac *.java
    java KopiSenjaMain

## Classes
- DrinkPreparation: interface (prepareDrink, calculateUnitPrice)
- Drink: base class (7 attributes from Assignment 1)
- CoffeeDrink, NonCoffeeDrink: derived classes
- Customer, Order, Payment, Receipt: additional classes
- KopiSenjaMain: main class
